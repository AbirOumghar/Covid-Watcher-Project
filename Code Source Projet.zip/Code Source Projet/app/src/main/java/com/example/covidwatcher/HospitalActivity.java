package com.example.covidwatcher;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Aditya Verma on 26-03-2020
 */

public class HospitalActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private HospitalAdapter mAdapter;
    private List<People> mHospitalList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital);

        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mHospitalList = new ArrayList<>();
        mHospitalList.add(new People("Tous les instituts medicals marocains"));
        mHospitalList.add(new People("HOPITAL CHEIKH ZAID, Rabat"));
        mHospitalList.add(new People("HOPITAL AR RAZI, Rabat"));
        mHospitalList.add(new People("CLINIQUE ANOUAL, Kenitra"));
        mHospitalList.add(new People("CLINIQUE ORTHOPEDIQUE (CCOTK), Kenitra"));
        mHospitalList.add(new People("CLINIQUE IBN ROCHD, Casa"));
        mHospitalList.add(new People("CLINIQUE LES ORANGERS, Casa"));
        mHospitalList.add(new People("Hopital Ibn Nafis, Marrakech"));
        mHospitalList.add(new People("Hopital El Antaki, Marrakech"));
        mHospitalList.add(new People("Hopital Al Qods Taza, Taza"));
        mHospitalList.add(new People("Hopital Ibn Tofail, Marrakech)"));
        mHospitalList.add(new People("HOPITAL IBNOU BAJA, Taza"));
        mHospitalList.add(new People("Govt. Medical college, Taza"));
        mHospitalList.add(new People("King's George Medical University, Rabat"));
        mHospitalList.add(new People("Institute of Medical Sciences, Banaras Hindu University, Fes "));
        mHospitalList.add(new People("Jawaharlal Nehru Medical College, Fes"));
        mHospitalList.add(new People("Government Medical College, Safi"));
        mHospitalList.add(new People("National Institute of Cholera and Enteric Diseases, Marrakesh"));
        mHospitalList.add(new People("Hopital Universitaire Denfants Abderrahim Harouchi, Mrrakesh"));
        mHospitalList.add(new People("Hopital Sidi Bernoussi, Meknes"));
        mHospitalList.add(new People("National Institute of Research in Tribal Health (NIRTH), Safi"));
        mHospitalList.add(new People("National Institute of Virology Field Unit, Rabat"));
        mHospitalList.add(new People("Govt. Medical College, Rabat"));
        mHospitalList.add(new People("Govt. Medical College, Casa"));
        mHospitalList.add(new People("Sidi Bernoussi2, Casa"));
        mHospitalList.add(new People("Sidi Bernoussi, Casa  "));
        mHospitalList.add(new People("National Institute of Virology Field Unit , Fes"));
        mHospitalList.add(new People("Mysore Medical College & Research Institute, Mysore"));
        mHospitalList.add(new People("Hassan Inst. of Med. Sciences, Hassan"));
        mHospitalList.add(new People("Shimoga Inst. of Med. Sciences, Shivamogga"));
        mHospitalList.add(new People("BJ Medical College, Safi"));
        mHospitalList.add(new People("MGM Medical College, Fes"));
        mHospitalList.add(new People("BPS Govt Medical College, Taroudant"));
        mHospitalList.add(new People("Pt. B.D. Sharma Post Graduate Inst. of Med. Sciences, Rabat"));
        mHospitalList.add(new People("Indira Gandhi Medical College, Shimla, Himachal Pradesh"));
        mHospitalList.add(new People("Dr. Rajendra Prasad Govt. Med. College, Kangra, Taza"));
        mHospitalList.add(new People("Sher-e- Kashmir Institute of Medical Sciences, Safi  "));
        mHospitalList.add(new People("Government Medical College, Fes"));
        mHospitalList.add(new People("Government Medical , Fes"));
        mHospitalList.add(new People("MGM Medical College, Fes"));
        mHospitalList.add(new People("NEIGRI of Health and Medical Sciences, Fes"));
        mHospitalList.add(new People("J N Hopital, Meysour"));
        mHospitalList.add(new People("Hopital Mohamed Sekkat, Safi"));
        mHospitalList.add(new People("Moulay El Hassan, Casa"));
        mHospitalList.add(new People("Government Medical College, Safi"));
        mHospitalList.add(new People("Government Medical , Safi"));
        mHospitalList.add(new People("Jawaharlal Institute of Postgraduate Medical Education & Research, Puducherry"));
        mHospitalList.add(new People("Centre Sante Saada Hay Mohammedi, Sale"));
        mHospitalList.add(new People("Hopital Dainchock, Errachidia"));
        mHospitalList.add(new People("Hopital Moulay Ali Charif, Errachidia"));
        mHospitalList.add(new People("Centre De Sante El Fida, Casa"));
        mHospitalList.add(new People("Centre hospitalier Sidi Yahia, El Jadida"));
        mHospitalList.add(new People("Centre hospitalier provincial DEL JADIDA, El Jadida"));
        mHospitalList.add(new People("Regional Medical Research Centre, Port Blair, Andaman and Nicobar"));
        mHospitalList.add(new People("Hopital Mohammed5, AlHoceima"));
        mHospitalList.add(new People("Hopital Touilaa, Tetouan"));
        mHospitalList.add(new People("Hopital IbnKhaldoun, Beni Mellal"));
        mHospitalList.add(new People("Hopital Hassan 2, Beni Mellal"));
        mHospitalList.add(new People("Hopital regional des specialites de Tetouan, Tetouan"));
        mHospitalList.add(new People("HOPITAL AL KORTOBI, Tanger"));
        mHospitalList.add(new People("HOPITAL MOHAMMED 5, Tanger"));
        mHospitalList.add(new People("CLINIQUE LA MENARA, Agadir"));
        mHospitalList.add(new People("CLINIQUE AL BOUSTANE, Agadir"));

        //set adapter to recyclerview
        mAdapter = new HospitalAdapter(mHospitalList,this);
        mRecyclerView.setAdapter(mAdapter);
    }

}
