package com.example.covidwatcher;

/**
 * Created by Aditya Verma on 26-03-2020
 */

public class People {

    String name;

    public People(String name) {
        this.name = name;
    }

    public People(String abraham_lincoln, String s) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
